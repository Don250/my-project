package com.netspring._carModel;

import com.netspring._carModel.model.Car;
import com.netspring._carModel.repository.CarDao;
import org.hibernate.grammars.importsql.SqlScriptParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	private CarDao cardao;
	@Override
	public void run(String...args) throws Exception{

		Car car= new Car();
		car.setPlateNo("RCA545P");
		car.setCarName("V8");
		car.setCarModel("Toyota");
		car.setCarType("No1");
		cardao.save(car);

		Car car2= new Car();
		car2.setPlateNo("RFA22T");
		car2.setCarName("Benz");
		car2.setCarModel("Toyota");
		car2.setCarType("No1");
		cardao.save(car2);



	}
}
