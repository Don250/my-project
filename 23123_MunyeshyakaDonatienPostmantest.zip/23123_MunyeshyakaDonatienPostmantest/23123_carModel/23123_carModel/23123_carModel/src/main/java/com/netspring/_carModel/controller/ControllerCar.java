package com.netspring._carModel.controller;

import com.netspring._carModel.exception.ResouceNotFoundException;
import com.netspring._carModel.model.Car;
import com.netspring._carModel.repository.CarDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/23123/cars")
public class ControllerCar {
    @Autowired

    private CarDao carDao;
    @GetMapping
    public List<Car> getAllCar(){
        return  carDao.findAll();
    }
    @PostMapping
    public Car createCar(@RequestBody Car car){
        return carDao.save(car);
    }
    @GetMapping("{plateNo}")
    public ResponseEntity<Car> getCarById(@PathVariable String plateNo){
        Car car = carDao.findById(plateNo).orElseThrow(() -> new ResouceNotFoundException("Car not exist with platecnumber:" +plateNo));
return ResponseEntity.ok(car);
    }
    @PutMapping("{plateNo}")
public ResponseEntity<Car> updateCar(@PathVariable String plateNo, @RequestBody Car carDetails){
        Car updCar = carDao.findById(plateNo).orElseThrow(() -> new ResouceNotFoundException("Car not exist with plate number:" +plateNo));


        updCar.setCarName(carDetails.getCarName());
        updCar.setCarModel(carDetails.getCarModel());
        updCar.setCarType(carDetails.getCarType());
        carDao.save(updCar);
        return ResponseEntity.ok(updCar);
}
@DeleteMapping("{plateNo}")
public ResponseEntity<HttpStatus> deleteCar(@PathVariable  String plateNo){

        Car cardelete = carDao.findById(plateNo).orElseThrow(() -> new ResouceNotFoundException("car not exist with plate number :" +plateNo));
        carDao.delete(cardelete);
        return  new ResponseEntity<>(HttpStatus.NO_CONTENT);

}
}

