package com.netspring._carModel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name="cars")
public class Car {
    @Id
    private String plateNo;
    @Column(name="car_name")
    private String carName;
    @Column(name="car_model")
    private String carModel;
    @Column(name="car_type")
    private String carType;


}
